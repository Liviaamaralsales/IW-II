import Crud from './Crud.js';

const crud = new Crud();

function gravar() {
const carro = {"nomecarro":"fe","cor":"azul"}        
        crud.save(carro, function(carro){
           // res.json(carro)
        })
}

//gravar()

function atualizar(){
    const carro = {"id":2,"nomecarro":"fe2","cor":"azul2"}  
    crud.update(carro.id,carro, function(carro){

    })

}

atualizar()

















