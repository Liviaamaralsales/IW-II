import Crud from "./Crud.js";

//Crud.prototype.save

const crud = new Crud()

function gravar(){
    let dog = {"dogsname": "Amora", 
               "dogcolor": "Caramel",
               "age": 7}

    crud.save(dog, function(dog){
        
    })
}